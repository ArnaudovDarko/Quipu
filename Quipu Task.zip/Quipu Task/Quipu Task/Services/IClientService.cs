﻿namespace Quipu_Task.Services
{
    public interface IClientService
    {
    }

    public class ClientService : IClientService 
    {
    
    }
}
