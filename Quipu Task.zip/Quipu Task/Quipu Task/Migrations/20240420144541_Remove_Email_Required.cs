﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Quipu_Task.Migrations
{
    /// <inheritdoc />
    public partial class Remove_Email_Required : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
